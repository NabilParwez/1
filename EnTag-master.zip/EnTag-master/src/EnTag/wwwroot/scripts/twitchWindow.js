﻿function OpenWindowT() {
    window.open("/oauth/twitch/", "_blank", "width=300, height=200, alwaysRaised=yes");
}