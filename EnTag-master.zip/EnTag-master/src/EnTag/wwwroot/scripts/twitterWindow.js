﻿function OpenWindow() {
    window.open("/oauth/twitter/", "_blank", "width=300, height=200, alwaysRaised=yes");
}

function OpenWindowT() {
    window.open("/oauth/twitch/", "_blank", "width=300, height=200, alwaysRaised=yes");
}

function OpenWindowS() {
    window.open("/oauth/spotify/", "_blank", "width=300, height=200, alwaysRaised=yes");
}
