/// <reference path="globals/angular-resource/index.d.ts" />
/// <reference path="globals/angular-ui-bootstrap/index.d.ts" />
/// <reference path="globals/angular-ui-router/index.d.ts" />
/// <reference path="globals/angular/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
